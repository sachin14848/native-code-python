//package com.apiGetway.utiles;
//
//
//import com.apiGetway.config.RSAKeyRecord;
//import com.apiGetway.config.UserInfoConfig;
//import com.apiGetway.repo.UserInfoRepo;
//import lombok.RequiredArgsConstructor;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.security.oauth2.jwt.Jwt;
//import org.springframework.security.oauth2.jwt.JwtDecoder;
//import org.springframework.security.oauth2.jwt.JwtException;
//import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
//import org.springframework.stereotype.Component;
//
//import java.time.Instant;
//import java.util.Objects;
//
//@Component
//@RequiredArgsConstructor
//public class JwtHelper {
//    private final RSAKeyRecord rsaKeyRecord;
//
//    public String getUserName(Jwt jwtToken) {
//        return jwtToken.getSubject();
//    }
//
//    public boolean isTokenValid(Jwt jwtToken, UserDetails userDetails) {
//        final String userName = getUserName(jwtToken);
//        boolean isTokenExpired = getIfTokenIsExpired(jwtToken);
//        boolean isTokenUserSameAsDatabase = userName.equals(userDetails.getUsername());
//        return !isTokenExpired && isTokenUserSameAsDatabase;
//    }
//
//    private boolean getIfTokenIsExpired(Jwt jwtToken) {
//        return Objects.requireNonNull(jwtToken.getExpiresAt()).isBefore(Instant.now());
//    }
//
//    public boolean getClaimsFromToken(String token) {
//        try {
//            final JwtDecoder jwtDecoder = NimbusJwtDecoder.withPublicKey(rsaKeyRecord.rsaPublicKey()).build();
//            jwtDecoder.decode(token);
//            return true;
//        } catch (JwtException e) {
//            return false;
//        }
//    }
//
//    private final UserInfoRepo userInfoRepo;
//
//    public UserDetails userDetails(String emailId) {
//        return userInfoRepo
//                .findByEmailId(emailId)
//                .map(UserInfoConfig::new)
//                .orElseThrow(() -> new UsernameNotFoundException("UserEmail: " + emailId + " does not exist"));
//    }
//}
