//package com.apiGetway.utiles;
//
//import com.apiGetway.config.RSAKeyRecord;
//import com.apiGetway.config.RouteValidator;
//import com.apiGetway.dto.error.ErrorResponse;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.core.io.buffer.DataBuffer;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.http.server.reactive.ServerHttpRequest;
//import org.springframework.security.core.context.ReactiveSecurityContextHolder;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.oauth2.jwt.Jwt;
//import org.springframework.security.oauth2.jwt.JwtDecoder;
//import org.springframework.security.oauth2.jwt.JwtException;
//import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
//import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
//import org.springframework.stereotype.Component;
//import org.springframework.util.StringUtils;
//import org.springframework.web.server.ServerWebExchange;
//import org.springframework.web.server.WebFilter;
//import org.springframework.web.server.WebFilterChain;
//import reactor.core.publisher.Mono;
//
//import java.nio.charset.StandardCharsets;
//
//@Slf4j
//@Component
//public class JwtAuthenticationFilter implements WebFilter {
//    //extends AbstractGatewayFilterFactory<JwtAuthenticationFilter.Config>
//    @Autowired
//    private JwtHelper jwtHelper;
//    @Autowired
//    private RSAKeyRecord rsaKeyRecord;
//    @Autowired
//    private RouteValidator validator;
//
//
//    public JwtAuthenticationFilter(RouteValidator routeValidator, RSAKeyRecord rsaKeyRecord, JwtHelper jwtHelper) {
//        this.validator = routeValidator;
//        this.rsaKeyRecord = rsaKeyRecord;
//        this.jwtHelper = jwtHelper;
//    }
//
//
//    @Override
//    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
//        log.info("Processing request: {}", exchange.getRequest().getPath());
//        if (validator.isSecured.test(exchange.getRequest())) {
//
//
//            log.info("Valid Request : ");
//            try {
//                final JwtDecoder jwtDecoder = NimbusJwtDecoder.withPublicKey(rsaKeyRecord.rsaPublicKey()).build();  // integrate the Decoder with RSA Public Key
//                String token = getTokenFromRequest(exchange.getRequest()); // get the token from Request Header
//                if (token != null) { // validate the token
//                    final Jwt jwtToken = jwtDecoder.decode(token); // decode the token
//                    final String userName = jwtHelper.getUserName(jwtToken); // extract the username from the token
//                    if (!userName.isEmpty() && SecurityContextHolder.getContext().getAuthentication() == null) { // check if the user is authenticated
//                        UserDetails userDetails = jwtHelper.userDetails(userName); // get user details from the database
//                        if (jwtHelper.isTokenValid(jwtToken, userDetails)) {  // validate the token with user details
//                            JwtAuthenticationToken tokens = new JwtAuthenticationToken(jwtToken, userDetails.getAuthorities(), userDetails.getUsername());  //`` the user details are attached to the SecurityContext
//                            return chain.filter(exchange).contextWrite(ReactiveSecurityContextHolder.withAuthentication(tokens));  // attach the authenticated user to the SecurityContext
//                        }
//                    } else {
//                        throw new JwtException("No authentication token found"); // if the user is not authenticated, throw an exception
//                    }
//                } else {
//                    throw new JwtException("Missing or invalid JWT token");  // if the token is missing or invalid, throw an exception
//                }
//            } catch (JwtException ex) {
//                return handleUnauthorized(exchange, "Invalid JWT token or expired token " + ex.getMessage());
//            } catch (Exception ex) {
//                return handleUnauthorized(exchange, "Error " + ex.getMessage());
//            }
//        }
//        return chain.filter(exchange);
//    }
//
//    private String getTokenFromRequest(ServerHttpRequest request) {
//        String bearerToken = request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
//        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
//            return bearerToken.substring(7);
//        }
//        return null;
//    }
//
//    private Mono<Void> handleUnauthorized(ServerWebExchange exchange, String message) {
//        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
//        exchange.getResponse().getHeaders().setContentType(MediaType.APPLICATION_JSON);
//        byte[] bytes = message.getBytes(StandardCharsets.UTF_8);
//        DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(bytes);
//        try {
//            ErrorResponse errorResponse = new ErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication failed", "error", message);
//            String json = new ObjectMapper().writeValueAsString(errorResponse);
//            buffer = exchange.getResponse().bufferFactory().wrap(json.getBytes(StandardCharsets.UTF_8));
//            return exchange.getResponse().writeWith(Mono.just(buffer));
//        } catch (JsonProcessingException ex) {
//            String error = "Response JSON convert Error : " + ex.getMessage();
//            buffer = exchange.getResponse().bufferFactory().wrap(error.getBytes(StandardCharsets.UTF_8));
//            return exchange.getResponse().writeWith(Mono.just(buffer));
//        }
//    }
//
//}
