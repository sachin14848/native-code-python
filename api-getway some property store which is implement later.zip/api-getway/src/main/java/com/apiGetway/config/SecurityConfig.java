//package com.apiGetway.config;
//
//import com.apiGetway.utiles.JwtAuthenticationFilter;
//import com.apiGetway.utiles.JwtHelper;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
//import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
//import org.springframework.security.config.web.server.ServerHttpSecurity;
//import org.springframework.security.web.server.context.ServerSecurityContextRepository;
//import org.springframework.security.web.server.SecurityWebFilterChain;
//import org.springframework.security.web.server.context.WebSessionServerSecurityContextRepository;
//
//import static org.springframework.security.config.Customizer.withDefaults;
//
//@Configuration
//@ConditionalOnProperty(value = "spring.security.enabled", havingValue = "true", matchIfMissing = false)
////@EnableWebSecurity
//public class SecurityConfig {
//
//    @Autowired
//    private RouteValidator validator;
//    @Autowired
//    private RSAKeyRecord rsaKeyRecord;
//
//    @Autowired
//    private JwtHelper jwtHelper;
//
//    @Bean
//    public SecurityWebFilterChain securityConfigFilter(ServerHttpSecurity http) throws Exception {
//        return http
//                .authorizeExchange(exchanges -> exchanges
//                        .pathMatchers("/mail/send").permitAll()
//                        .anyExchange().authenticated())
//                .oauth2ResourceServer(oauth -> oauth.jwt(withDefaults()))
//                .addFilterAt(new JwtAuthenticationFilter(validator, rsaKeyRecord, jwtHelper), SecurityWebFiltersOrder.AUTHENTICATION)
//                .build();
//    }
//
//}
